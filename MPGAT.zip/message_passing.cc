﻿#include "message_passing.h"
#include "hls_math.h"

typedef struct {
    int node_idx;
    int degree;
} node_t;

// #region Internal Function Declarations
static void read_node_degrees(
    int pe_id,
    hls::stream<int>& degrees,
    hls::stream<node_t>& nonzero_degree_nodes,
    hls::stream<node_t>& nonzero_degree_nodes2,
    int node_count
);
static void top_k_attention_accumulation(
    hls::stream<FEATURE_MAP_VECTOR>& threshold_score,
    int pe_id,
    hls::stream<node_t>& nonzero_degree_nodes,
    FEATURE_MAP_VECTOR node_embedding_buffer[ceildiv(MAX_NODE_COUNT, EDGE_PARALLEL_FACTOR)][EMBEDDING_DIM],
    FEATURE_MAP_VECTOR source_attention_scores[MAX_NODE_COUNT],
    FEATURE_MAP_VECTOR target_attention_scores[ceildiv(MAX_NODE_COUNT, EDGE_PARALLEL_FACTOR)]
);
static void gather_node_messages(
    hls::stream<FEATURE_MAP_VECTOR>& threshold_score,
    int pe_id,
    hls::stream<node_t>& nonzero_degree_nodes,
    FEATURE_MAP_VECTOR node_embedding_buffer[ceildiv(MAX_NODE_COUNT, EDGE_PARALLEL_FACTOR)][EMBEDDING_DIM],
    FEATURE_MAP_VECTOR source_attention_scores[MAX_NODE_COUNT],
    FEATURE_MAP_VECTOR target_attention_scores[ceildiv(MAX_NODE_COUNT, EDGE_PARALLEL_FACTOR)],
    hls::stream<msg_passing_output_t>& messages,
    hls::stream<FEATURE_MAP_VECTOR>& attention_score_sums
);
static void expand_node_messages(
    hls::stream<msg_passing_output_t>& messages_per_nz_deg_node,
    hls::stream<FEATURE_MAP_VECTOR>& attention_score_sums_per_nz_deg_node,
    hls::stream<int>& degrees,
    hls::stream<msg_passing_output_t> messages_per_node[NODE_PARALLEL_FACTOR],
    hls::stream<FEATURE_MAP_VECTOR> attention_score_sums_per_node[NODE_PARALLEL_FACTOR],
    int node_count
);
// #endregion


void message_passing_pe(
    int pe_id,
    FEATURE_MAP_VECTOR node_embedding_buffer[ceildiv(MAX_NODE_COUNT, EDGE_PARALLEL_FACTOR)][EMBEDDING_DIM],
    FEATURE_MAP_VECTOR source_attention_scores[MAX_NODE_COUNT],
    FEATURE_MAP_VECTOR target_attention_scores[ceildiv(MAX_NODE_COUNT, EDGE_PARALLEL_FACTOR)],
    hls::stream<msg_passing_output_t> messages[NODE_PARALLEL_FACTOR],
    hls::stream<FEATURE_MAP_VECTOR> attention_score_sums[NODE_PARALLEL_FACTOR],
    int node_count
)
{
#pragma HLS INLINE off
#pragma HLS DATAFLOW

    hls::stream<int> degrees("degrees");
#pragma HLS STREAM variable=degrees depth=20
    hls::stream<node_t> nonzero_degree_nodes("nonzero_degree_nodes");
#pragma HLS STREAM variable=nonzero_degree_nodes depth=20
    hls::stream<node_t> nonzero_degree_nodes2("nonzero_degree_nodes2");
#pragma HLS STREAM variable=nonzero_degree_nodes2 depth=20
    hls::stream<msg_passing_output_t> messages_per_nz_deg_node("messages_per_nz_deg_node");
#pragma HLS STREAM variable=messages_per_nz_deg_node depth=(20 * ceildiv(EMBEDDING_DIM, GATHER_PARALLEL_FACTOR))
    hls::stream<FEATURE_MAP_VECTOR> attention_score_sums_per_nz_deg_node("attention_score_sums_per_nz_deg_node");
#pragma HLS STREAM variable=attention_score_sums_per_nz_deg_node depth=20
    hls::stream<FEATURE_MAP_VECTOR> threshold_score("threshold_score");
#pragma HLS STREAM variable=threshold_score depth=20

    read_node_degrees(pe_id, degrees, nonzero_degree_nodes, nonzero_degree_nodes2, node_count);
    top_k_attention_accumulation(threshold_score, pe_id, nonzero_degree_nodes, node_embedding_buffer, source_attention_scores, target_attention_scores);
    gather_node_messages(threshold_score, pe_id, nonzero_degree_nodes2, node_embedding_buffer, source_attention_scores, target_attention_scores, messages_per_nz_deg_node, attention_score_sums_per_nz_deg_node);
    expand_node_messages(messages_per_nz_deg_node, attention_score_sums_per_nz_deg_node, degrees, messages, attention_score_sums, node_count);
}


static void read_node_degrees(
    int pe_id,
    hls::stream<int>& degrees,
    hls::stream<node_t>& nonzero_degree_nodes,
    hls::stream<node_t>& nonzero_degree_nodes2,
    int node_count
)
{
#pragma HLS INLINE off

    for (int node_idx = 0; node_idx < node_count; node_idx++)
    {
#pragma HLS LOOP_TRIPCOUNT min=GRAPH_ANALYSIS_MIN_NODE_NUM max=GRAPH_ANALYSIS_MAX_NODE_NUM avg=GRAPH_ANALYSIS_AVG_NODE_NUM
        int degree = parallel_degree_tables[pe_id][node_idx];
        degrees << degree;
        if (degree != 0)
        {
            nonzero_degree_nodes << node_t{node_idx, degree};
            nonzero_degree_nodes2 << node_t{node_idx, degree};
        }
    }
}


///////////////////////////////////////////////////////////////////////////////////////////////
static FEATURE_MAP_VECTOR activate_attention_scores(FEATURE_MAP_VECTOR attention_scores)
{
#pragma HLS INLINE
    for (int head_idx = 0; head_idx < ATTENTION_HEAD_NUM; head_idx++)
    {
#pragma HLS UNROLL
        FEATURE_MAP_TYPE score = attention_scores[head_idx];
        if (score < 0) score = score * FEATURE_MAP_TYPE(0.2);
        attention_scores[head_idx] = hls::exp(score);
    }
    return attention_scores;
}


static FEATURE_MAP_TYPE reduce_attention_score(FEATURE_MAP_VECTOR attention_scores)
{
#pragma HLS INLINE
    FEATURE_MAP_TYPE score_sum = FEATURE_MAP_TYPE(0);
    for (int head_idx = 0; head_idx < ATTENTION_HEAD_NUM; head_idx++)
    {
#pragma HLS UNROLL
        score_sum += attention_scores[head_idx];
    }
    return score_sum / FEATURE_MAP_TYPE(ATTENTION_HEAD_NUM);
}


static void top_k_attention_accumulation(
    hls::stream<FEATURE_MAP_VECTOR>& threshold_score,
    int pe_id,
    hls::stream<node_t>& nonzero_degree_nodes,
    FEATURE_MAP_VECTOR node_embedding_buffer[ceildiv(MAX_NODE_COUNT, EDGE_PARALLEL_FACTOR)][EMBEDDING_DIM],
    FEATURE_MAP_VECTOR source_attention_scores[MAX_NODE_COUNT],
    FEATURE_MAP_VECTOR target_attention_scores[ceildiv(MAX_NODE_COUNT, EDGE_PARALLEL_FACTOR)]
)
{
#pragma HLS INLINE off
    (void)node_embedding_buffer;

    FEATURE_MAP_TYPE attention_score_buffer[MAX_EDGE_COUNT];
#pragma HLS BIND_STORAGE variable=attention_score_buffer type=ram_2p impl=bram

    const int lower_k_bound = NEIGHBOR_BASE - RANGE_OFFSET; // K - A
    const int upper_k_bound = NEIGHBOR_BASE + RANGE_OFFSET; // K + A
    const int mid_keep_count = TOPK_KEEP_MID;               // Y
    const int high_keep_count = TOPK_KEEP_HIGH;             // Z
    const int edge_count = edge_count_per_pe[pe_id];

    int edge_idx_base = 0;
    while (edge_idx_base < edge_count)
    {
#pragma HLS LOOP_TRIPCOUNT min=0 max=GRAPH_ANALYSIS_MAX_NODE_NUM avg=GRAPH_ANALYSIS_AVG_NODE_NUM
        node_t node;
        nonzero_degree_nodes >> node;

        const int target_node_idx = node.node_idx;
        const int degree = node.degree;

        int keep_count;
        if (degree <= lower_k_bound)
        {
            keep_count = degree;
        }
        else if (degree < upper_k_bound)
        {
            keep_count = mid_keep_count;
        }
        else
        {
            keep_count = high_keep_count;
        }

        if (keep_count < 1) keep_count = 1;
        if (keep_count > degree) keep_count = degree;

        FEATURE_MAP_TYPE min_score = FEATURE_MAP_TYPE(0);
        FEATURE_MAP_TYPE max_score = FEATURE_MAP_TYPE(0);

        for (int nbr_idx = 0; nbr_idx < degree; nbr_idx++)
        {
#pragma HLS LOOP_TRIPCOUNT min=0 max=GRAPH_ANALYSIS_MAX_EDGE_NUM avg=ceildiv(GRAPH_ANALYSIS_AVG_EDGE_NUM, EDGE_PARALLEL_FACTOR)
#pragma HLS PIPELINE II=1
            const int source_node_idx = parallel_neighbor_tables2[pe_id][edge_idx_base + nbr_idx];
            FEATURE_MAP_VECTOR attention_scores = source_attention_scores[target_node_idx] + target_attention_scores[source_node_idx];
            attention_scores = activate_attention_scores(attention_scores);
            FEATURE_MAP_TYPE scalar_score = reduce_attention_score(attention_scores);
            attention_score_buffer[nbr_idx] = scalar_score;

            if (nbr_idx == 0)
            {
                min_score = scalar_score;
                max_score = scalar_score;
            }
            else
            {
                if (scalar_score < min_score) min_score = scalar_score;
                if (scalar_score > max_score) max_score = scalar_score;
            }
        }

        FEATURE_MAP_TYPE threshold_scalar = min_score;
        if (keep_count < degree)
        {
            FEATURE_MAP_TYPE low = min_score;
            FEATURE_MAP_TYPE high = max_score;

            for (int iter = 0; iter < 12; iter++)
            {
                FEATURE_MAP_TYPE mid = (low + high) * FEATURE_MAP_TYPE(0.5);
                int ge_count = 0;

                for (int nbr_idx = 0; nbr_idx < degree; nbr_idx++)
                {
#pragma HLS LOOP_TRIPCOUNT min=0 max=GRAPH_ANALYSIS_MAX_EDGE_NUM avg=ceildiv(GRAPH_ANALYSIS_AVG_EDGE_NUM, EDGE_PARALLEL_FACTOR)
#pragma HLS PIPELINE II=1
                    if (attention_score_buffer[nbr_idx] >= mid) ge_count++;
                }

                if (ge_count >= keep_count)
                {
                    low = mid;
                }
                else
                {
                    high = mid;
                }
            }
            threshold_scalar = low;
        }

        threshold_score << FEATURE_MAP_VECTOR(threshold_scalar);
        edge_idx_base += degree;
    }
}


static void gather_node_messages(
    hls::stream<FEATURE_MAP_VECTOR>& threshold_score,
    int pe_id,
    hls::stream<node_t>& nonzero_degree_nodes,
    FEATURE_MAP_VECTOR node_embedding_buffer[ceildiv(MAX_NODE_COUNT, EDGE_PARALLEL_FACTOR)][EMBEDDING_DIM],
    FEATURE_MAP_VECTOR source_attention_scores[MAX_NODE_COUNT],
    FEATURE_MAP_VECTOR target_attention_scores[ceildiv(MAX_NODE_COUNT, EDGE_PARALLEL_FACTOR)],
    hls::stream<msg_passing_output_t>& messages,
    hls::stream<FEATURE_MAP_VECTOR>& attention_score_sums
)
{
#pragma HLS INLINE off
#pragma HLS DATAFLOW
    msg_passing_output_t msg_passing_outs[ceildiv(EMBEDDING_DIM, GATHER_PARALLEL_FACTOR)];
    FEATURE_MAP_VECTOR attention_score_sums_acc;
    int target_node_idx = 0;
    int edge_start = 0;
    int edge_end = 0;
    int edge_count = edge_count_per_pe[pe_id];

    FEATURE_MAP_VECTOR threshold;
    for (int edge_idx = 0; edge_idx < edge_count; edge_idx++)
    {
#pragma HLS LOOP_TRIPCOUNT min=0 max=GRAPH_ANALYSIS_MAX_EDGE_NUM avg=ceildiv(GRAPH_ANALYSIS_AVG_EDGE_NUM, EDGE_PARALLEL_FACTOR)

        int source_node_idx = parallel_neighbor_tables2[pe_id][edge_idx];

        for (int iter_idx = 0, dim_base = 0; iter_idx < ceildiv(EMBEDDING_DIM, GATHER_PARALLEL_FACTOR); iter_idx++, dim_base += GATHER_PARALLEL_FACTOR)
        {
#pragma HLS PIPELINE

            if (edge_idx >= edge_end)
            {
                node_t node;
                nonzero_degree_nodes >> node;
                target_node_idx = node.node_idx;
                edge_start = edge_idx;
                edge_end = edge_idx + node.degree;
                attention_score_sums_acc = FEATURE_MAP_TYPE(0);
                threshold_score >> threshold;
            }

            FEATURE_MAP_VECTOR attention_scores = source_attention_scores[target_node_idx] + target_attention_scores[source_node_idx];
            attention_scores = activate_attention_scores(attention_scores);

            if (reduce_attention_score(attention_scores) < threshold[0])
            {
                attention_scores = FEATURE_MAP_VECTOR(0);
            }
            if (iter_idx == 0) attention_score_sums_acc += attention_scores;

            msg_passing_output_t msg_passing_out = (edge_idx != edge_start) ? msg_passing_outs[iter_idx] : FEATURE_MAP_VECTOR(0);

            for (int dim_offset = 0; dim_offset < GATHER_PARALLEL_FACTOR; dim_offset++)
            {
#pragma HLS UNROLL
                int dim = dim_base + dim_offset;
                if (dim < EMBEDDING_DIM)
                {
                    msg_passing_out[dim_offset] += attention_scores * node_embedding_buffer[source_node_idx][dim];
                }
            }

            msg_passing_outs[iter_idx] = msg_passing_out;

            if (edge_idx + 1 == edge_end)
            {
                messages << msg_passing_out;
                if (iter_idx == 0) attention_score_sums << attention_score_sums_acc;
            }
        }
    }
}


static void expand_node_messages(
    hls::stream<msg_passing_output_t>& messages_per_nz_deg_node,
    hls::stream<FEATURE_MAP_VECTOR>& attention_score_sums_per_nz_deg_node,
    hls::stream<int>& degrees,
    hls::stream<msg_passing_output_t> messages_per_node[NODE_PARALLEL_FACTOR],
    hls::stream<FEATURE_MAP_VECTOR> attention_score_sums_per_node[NODE_PARALLEL_FACTOR],
    int node_count
)
{
#pragma HLS INLINE off

    int degree;

    for (int node_idx = 0; node_idx < node_count; node_idx++)
    {
#pragma HLS LOOP_TRIPCOUNT min=GRAPH_ANALYSIS_MIN_NODE_NUM max=GRAPH_ANALYSIS_MAX_NODE_NUM avg=GRAPH_ANALYSIS_AVG_NODE_NUM

        for (int iter_idx = 0; iter_idx < ceildiv(EMBEDDING_DIM, GATHER_PARALLEL_FACTOR); iter_idx++)
        {
#pragma HLS PIPELINE II=1

            if (iter_idx == 0)
            {
#pragma HLS OCCURRENCE cycle=ceildiv(EMBEDDING_DIM, GATHER_PARALLEL_FACTOR)
                degrees >> degree;

                FEATURE_MAP_VECTOR attention_score_sum;
                if (degree != 0)
                {
                    attention_score_sums_per_nz_deg_node >> attention_score_sum;
                }
                else
                {
                    attention_score_sum = FEATURE_MAP_TYPE(0);
                }

                attention_score_sums_per_node[node_idx % NODE_PARALLEL_FACTOR] << attention_score_sum;
            }

            msg_passing_output_t message;

            if (degree != 0)
            {
                messages_per_nz_deg_node >> message;
            }
            else
            {
                message = FEATURE_MAP_VECTOR(0);
            }

            messages_per_node[node_idx % NODE_PARALLEL_FACTOR] << message;
        }
    }
}
